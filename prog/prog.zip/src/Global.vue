<script>
    const server_config = {
        url: 'http://47.103.212.224:8088',
        userId:'10000',

    };
    let hasProject = false;
    let projectDetails = {};
    export default {
        server_config,
        hasProject,
        projectDetails
    }
</script>

