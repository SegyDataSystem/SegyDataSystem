let global = {
    base_url : 'http://47.103.212.224:8080',
    
}


export default global;